package com.ioslock
import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {
    override fun onListenerConnected() = refresh()
    override fun onNotificationPosted(s: StatusBarNotification?) = refresh()
    override fun onNotificationRemoved(s: StatusBarNotification?) = refresh()
    private fun refresh() {
        try {
            val list = activeNotifications.filter { !it.isOngoing && it.packageName != packageName }.map {
                val e = it.notification.extras
                val app = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(it.packageName, 0)).toString() } catch (x: Exception) { it.packageName }
                N(app, e.getCharSequence("android.title")?.toString() ?: "", e.getCharSequence("android.text")?.toString() ?: "")
            }
            Store.notifs.clear(); Store.notifs.addAll(list)
            val msm = getSystemService(MediaSessionManager::class.java)
            val c = msm.getActiveSessions(ComponentName(this, NotifService::class.java)).firstOrNull()
            Store.media = c?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
        } catch (_: Exception) {}
    }
}

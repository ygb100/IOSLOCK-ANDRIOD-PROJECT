package com.ioslock
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.ServiceCompat

class ScreenService : Service() {
    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            c.startActivity(Intent(c, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
    override fun onCreate() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("lock", "Lock screen", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "lock").setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("iOS Lock active").build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        registerReceiver(rx, IntentFilter(Intent.ACTION_SCREEN_ON))
    }
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onDestroy() { unregisterReceiver(rx) }
    override fun onBind(i: Intent?): IBinder? = null
}
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { c.startForegroundService(Intent(c, ScreenService::class.java)) }
}

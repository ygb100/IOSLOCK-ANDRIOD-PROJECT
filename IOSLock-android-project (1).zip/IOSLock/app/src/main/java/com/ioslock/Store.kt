package com.ioslock
import androidx.compose.runtime.*
data class N(val app: String, val title: String, val text: String)
object Store {
    val notifs = mutableStateListOf<N>()
    var media by mutableStateOf<String?>(null)
}

package com.ioslock
import android.app.KeyguardManager
import android.content.*
import android.hardware.*
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

class LockActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true); setTurnScreenOn(true)
        window.setDecorFitsSystemWindows(false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { LockScreen(::unlock, ::camera) }
    }
    private fun camera() {
        unlockThen { startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
    private fun unlock() = unlockThen {}
    private fun unlockThen(after: () -> Unit) {
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isKeyguardLocked) { after(); finish(); return }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { after(); finish() }
        })
    }
}

@Composable
fun LockScreen(onUnlock: () -> Unit, onCamera: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler {}
    // Clock
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }
    // Battery
    var batt by remember { mutableStateOf(0) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {
            batt = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) } }
        ctx.registerReceiver(r, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        onDispose { ctx.unregisterReceiver(r) }
    }
    // Gyro parallax
    var tilt by remember { mutableStateOf(Offset.Zero) }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) { tilt = Offset(-e.values[0] * 3f, e.values[1] * 3f) }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        sm.getDefaultSensor(Sensor.TYPE_GRAVITY)?.let { sm.registerListener(l, it, SensorManager.SENSOR_DELAY_UI) }
        onDispose { sm.unregisterListener(l) }
    }
    // Animated wallpaper (dynamic, offline)
    val t by rememberInfiniteTransition(label = "bg").animateFloat(0f, 1f,
        infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Reverse), label = "t")
    val bg = Brush.linearGradient(listOf(Color(0xFF1B1464).copy(alpha = 1f), Color(0xFFB5179E), Color(0xFFFF7B54)),
        start = Offset(0f, 0f), end = Offset(600f + 900f * t, 1800f))
    var drag by remember { mutableStateOf(0f) }
    var torch by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(bg)
        .pointerInput(Unit) { detectVerticalDragGestures(
            onDragEnd = { if (drag < -300f) onUnlock(); drag = 0f },
            onDragCancel = { drag = 0f }) { _, d -> drag += d } }
        .offset { IntOffset(0, drag.coerceAtMost(0f).toInt() / 3) }
    ) {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            // Dynamic Island-style pill
            val pill = Store.media
            Box(Modifier.padding(top = 6.dp).clip(CircleShape).background(Color.Black)
                .padding(horizontal = 18.dp, vertical = 8.dp)) {
                Text(if (pill != null) "♪ $pill" else "🔋 $batt%", color = Color.White, fontSize = 13.sp, maxLines = 1)
            }
            Spacer(Modifier.height(40.dp))
            Text(SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(now),
                color = Color.White.copy(0.85f), fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Text(SimpleDateFormat("h:mm", Locale.getDefault()).format(now),
                color = Color.White.copy(0.92f), fontSize = 112.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.offset { IntOffset((tilt.x * 2).toInt(), (tilt.y * 2).toInt()) })
            Spacer(Modifier.weight(1f))
            // Notification stack (latest 3)
            Store.notifs.takeLast(3).reversed().forEach {
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(22.dp))
                    .background(Color.White.copy(0.22f)).padding(14.dp)) {
                    Text(it.app, color = Color.White.copy(0.7f), fontSize = 12.sp)
                    Text(it.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text(it.text, color = Color.White.copy(0.85f), fontSize = 14.sp, maxLines = 2)
                }
            }
            if (Store.notifs.size > 3) Text("+${Store.notifs.size - 3} more", color = Color.White.copy(0.7f), fontSize = 12.sp)
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                RoundBtn(if (torch) "🔦" else "💡") {
                    val cm = ctx.getSystemService(CameraManager::class.java)
                    try { torch = !torch; cm.setTorchMode(cm.cameraIdList[0], torch) } catch (_: Exception) {}
                }
                RoundBtn("📷") { onCamera() }
            }
            Spacer(Modifier.height(14.dp))
            Text("Swipe up to unlock", color = Color.White.copy(0.7f), fontSize = 13.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
fun RoundBtn(label: String, onClick: () -> Unit) {
    Box(Modifier.size(56.dp).clip(CircleShape).background(Color.Black.copy(0.35f)).clickable { onClick() },
        contentAlignment = Alignment.Center) { Text(label, fontSize = 22.sp) }
}

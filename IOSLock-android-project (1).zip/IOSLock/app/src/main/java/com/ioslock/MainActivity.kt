package com.ioslock
import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) {
            Column(Modifier.padding(24.dp).systemBarsPadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("iOS Lock setup", style = MaterialTheme.typography.headlineMedium)
                Text("Grant all 3 steps, then start. Works fully offline.")
                Button(onClick = { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }) { Text("1. Allow display over apps") }
                Button(onClick = { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }) { Text("2. Allow notification access") }
                Button(onClick = { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("3. Disable battery optimization") }
                Button(onClick = { startForegroundService(Intent(this@MainActivity, ScreenService::class.java)) }) { Text("Start lock screen") }
                OutlinedButton(onClick = { stopService(Intent(this@MainActivity, ScreenService::class.java)) }) { Text("Stop") }
            } } } }
    }
}

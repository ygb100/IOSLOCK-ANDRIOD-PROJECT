BUILD: Open this folder in Android Studio (Koala+), let Gradle sync, then Build > Build APK(s).
INSTALL, open "iOS Lock", complete steps 1-3, tap Start lock screen, then lock/wake the phone.
Unlocking uses Android's real keyguard (PIN/fingerprint). Works fully offline.

NO ANDROID STUDIO? Upload this folder to a new GitHub repo (keep the .github folder). Open the Actions tab, run "Build APK", then download IOSLock-debug-apk from the finished run.
